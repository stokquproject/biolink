# docker-compose.yml

Berikut adalah referensi konfigurasi untuk `docker-compose.yml` agar Anda bisa menjalankan dan mengelola kontainer Docker dengan satu perintah mudah.

> **Catatan**: Ubah nama file ini menjadi `docker-compose.yml` (tanpa ekstensi .md) saat Anda siap menggunakannya.

```yaml
version: '3.8'

services:
  biolink-app:
    container_name: biolink-container
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      # Format: "Port-di-Host : Port-di-Container"
      # Anda bisa mengubah port 8080 sesuai keinginan (misal: "80:80")
      - "8080:80" 
    restart: unless-stopped
    environment:
      - NODE_ENV=production
```
