import { 
  Github, 
  Twitter, 
  Instagram, 
  Linkedin, 
  Mail, 
  Globe, 
  Youtube, 
  ShoppingCart,
  MapPin,
  MessageCircle,
  Folder,
  Briefcase
} from 'lucide-react';

export const config = {
  // Profile Information
  profile: {
    name: 'Stokqu Project',
    verified: true,
    bio: 'Software Engineer & Open Source Contributor. Building things for the web.',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80', // Premium looking portrait
  },

  // Link Groups
  linkGroups: [
    {
      title: 'Featured',
      links: [
        {
          title: 'My Portfolio',
          url: 'https://example.com',
          icon: Globe,
        },
        {
          title: 'Latest YouTube Video',
          url: 'https://youtube.com',
          icon: Youtube,
        },
      ]
    },
    {
      title: '🛍️ My Stores',
      links: [
        {
          title: 'Store / Merch',
          url: 'https://example.com/store',
          icon: ShoppingCart,
        },
        {
          title: 'Our Location',
          url: 'https://maps.google.com',
          icon: MapPin,
        }
      ]
    },
    {
      title: '💼 Work & Contact',
      links: [
        {
          title: 'Archived Projects',
          icon: Folder,
          subLinks: [
            {
              title: 'Project Alpha',
              url: 'https://example.com/alpha',
              icon: Briefcase
            },
            {
              title: 'Project Beta',
              url: 'https://example.com/beta',
              icon: Briefcase
            }
          ]
        },
        {
          title: 'Chat on WhatsApp',
          url: 'https://wa.me/1234567890',
          icon: MessageCircle,
        },
      ]
    }
  ],

  // Social Media Icons (Bottom Bar)
  socials: [
    {
      platform: 'GitHub',
      url: 'https://github.com',
      icon: Github,
    },
    {
      platform: 'Twitter',
      url: 'https://twitter.com',
      icon: Twitter,
    },
    {
      platform: 'Instagram',
      url: 'https://instagram.com',
      icon: Instagram,
    },
    {
      platform: 'LinkedIn',
      url: 'https://linkedin.com',
      icon: Linkedin,
    },
    {
      platform: 'Email',
      url: 'mailto:hello@example.com',
      icon: Mail,
    },
  ],

  // Theme Configuration
  theme: {
    // These colors are used as fallback or specific overrides, 
    // but the app primarily uses Tailwind utility classes for easy customization.
    primaryColor: '#3b82f6', // blue-500
  }
};
